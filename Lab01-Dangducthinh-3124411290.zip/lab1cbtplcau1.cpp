#include <iostream>
#include <cstring>
using namespace std;

#define MAX 100

// Khai báo cấu trúc Nhân Viên
struct NhanVien {
    char maSo[11];
    char ho[11];
    char ten[51];
    int phai; // 0: Nữ, 1: Nam
    int thamNien; // Số năm làm việc
};

// Khai báo cấu trúc Phòng Ban
struct PhongBan {
    NhanVien aNhanVien[MAX];
    int soLuong;
};

// Hàm nhập danh sách nhân viên
void NhapPhongBan(PhongBan &pb) {
    cout << "Nhap so luong nhan vien: ";
    cin >> pb.soLuong;
    cin.ignore();
    for (int i = 0; i < pb.soLuong; i++) {
        cout << "\nNhap thong tin nhan vien thu " << i + 1 << ":\n";
        cout << "Ma so: "; cin.getline(pb.aNhanVien[i].maSo, 11);
        cout << "Ho: "; cin.getline(pb.aNhanVien[i].ho, 11);
        cout << "Ten: "; cin.getline(pb.aNhanVien[i].ten, 51);
        do {
            cout << "Phai (0: Nu, 1: Nam): ";
            cin >> pb.aNhanVien[i].phai;
        } while (pb.aNhanVien[i].phai != 0 && pb.aNhanVien[i].phai != 1);
        do {
            cout << "Tham nien: ";
            cin >> pb.aNhanVien[i].thamNien;
        } while (pb.aNhanVien[i].thamNien < 0);
        cin.ignore();
    }
}

// Hàm xuất danh sách nhân viên
void XuatPhongBan(const PhongBan &pb) {
    cout << "\nDanh sach nhan vien:\n";
    for (int i = 0; i < pb.soLuong; i++) {
        cout << "Ma so: " << pb.aNhanVien[i].maSo << " | Ho: " << pb.aNhanVien[i].ho
             << " | Ten: " << pb.aNhanVien[i].ten << " | Phai: "
             << (pb.aNhanVien[i].phai == 1 ? "Nam" : "Nu")
             << " | Tham nien: " << pb.aNhanVien[i].thamNien << " nam\n";
    }
}

// Hàm đếm sĩ số nhân viên theo giới tính
void DemSiSo(const PhongBan &pb, int &sonam, int &sonu) {
    sonam = 0;
    sonu = 0;
    for (int i = 0; i < pb.soLuong; i++) {
        if (pb.aNhanVien[i].phai == 1)
            sonam++;
        else
            sonu++;
    }
}

// Hàm sắp xếp danh sách nhân viên tăng dần theo thâm niên
void SapXepTangTheoThamNien(PhongBan &pb) {
    for (int i = 0; i < pb.soLuong - 1; i++) {
        for (int j = i + 1; j < pb.soLuong; j++) {
            if (pb.aNhanVien[i].thamNien > pb.aNhanVien[j].thamNien) {
                swap(pb.aNhanVien[i], pb.aNhanVien[j]);
            }
        }
    }
}

// Hàm main
int main() {
    PhongBan pb;
    NhapPhongBan(pb);
    XuatPhongBan(pb);
    
    int sonam, sonu;
    DemSiSo(pb, sonam, sonu);
    cout << "\nSo luong Nam: " << sonam << " | So luong Nu: " << sonu << "\n";
    
    SapXepTangTheoThamNien(pb);
    cout << "\nDanh sach sau khi sap xep theo tham nien:\n";
    XuatPhongBan(pb);
    
    return 0;
}
