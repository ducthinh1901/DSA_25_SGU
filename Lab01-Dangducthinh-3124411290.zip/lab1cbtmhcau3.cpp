#include <iostream>
#include <cstring>
using namespace std;

#define MAX 50

// Khai báo cấu trúc HocSinh
struct HocSinh {
    char maSo[11];
    char ho[11];
    char ten[51];
    int phai; // 0: Nữ, 1: Nam
    int namSinh;
};

// Khai báo cấu trúc LopHoc
struct LopHoc {
    HocSinh aHocSinh[MAX];
    int soLuong;
};

// Hàm nhập danh sách học sinh
void NhapLopHoc(LopHoc &lop) {
    cout << "Nhap so luong hoc sinh: ";
    cin >> lop.soLuong;
    while (lop.soLuong <= 0 || lop.soLuong > MAX) {
        cout << "So luong khong hop le, nhap lai: ";
        cin >> lop.soLuong;
    }
    cin.ignore();
    for (int i = 0; i < lop.soLuong; i++) {
        cout << "Nhap thong tin hoc sinh thu " << i + 1 << ":\n";
        cout << "Ma so: "; cin.getline(lop.aHocSinh[i].maSo, 11);
        cout << "Ho: "; cin.getline(lop.aHocSinh[i].ho, 11);
        cout << "Ten: "; cin.getline(lop.aHocSinh[i].ten, 51);
        cout << "Phai (0: Nu, 1: Nam): "; cin >> lop.aHocSinh[i].phai;
        cout << "Nam sinh: "; cin >> lop.aHocSinh[i].namSinh;
        cin.ignore();
    }
}

// Hàm xuất danh sách học sinh
void XuatLopHoc(const LopHoc &lop) {
    cout << "Danh sach hoc sinh:\n";
    for (int i = 0; i < lop.soLuong; i++) {
        cout << "Ma so: " << lop.aHocSinh[i].maSo << ", Ho: " << lop.aHocSinh[i].ho << ", Ten: " << lop.aHocSinh[i].ten << ", Phai: " << (lop.aHocSinh[i].phai == 1 ? "Nam" : "Nu") << ", Nam sinh: " << lop.aHocSinh[i].namSinh << "\n";
    }
}

// Hàm đếm sĩ số học sinh nam và nữ
void DemSiSo(const LopHoc &lop, int &soNam, int &soNu) {
    soNam = 0;
    soNu = 0;
    for (int i = 0; i < lop.soLuong; i++) {
        if (lop.aHocSinh[i].phai == 1)
            soNam++;
        else
            soNu++;
    }
}

// Hàm sắp xếp danh sách tăng dần theo năm sinh
void SapXepTangTheoNamSinh(LopHoc &lop) {
    for (int i = 0; i < lop.soLuong - 1; i++) {
        for (int j = i + 1; j < lop.soLuong; j++) {
            if (lop.aHocSinh[i].namSinh > lop.aHocSinh[j].namSinh) {
                swap(lop.aHocSinh[i], lop.aHocSinh[j]);
            }
        }
    }
}

int main() {
    LopHoc lop;
    NhapLopHoc(lop);
    
    int soNam, soNu;
    DemSiSo(lop, soNam, soNu);
    cout << "Si so Nam: " << soNam << ", Si so Nu: " << soNu << "\n";
    
    SapXepTangTheoNamSinh(lop);
    XuatLopHoc(lop);
    
    return 0;
}