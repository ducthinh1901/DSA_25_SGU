#include <iostream>
using namespace std;

#define MAX 100 // Số lượng phần tử tối đa của dãy

// Hàm tách mảng thành số chẵn và số lẻ
void TachMang(int *a, int n, int *b, int &m, int *c, int &p) {
    m = 0; // Số lượng phần tử của mảng b (số chẵn)
    p = 0; // Số lượng phần tử của mảng c (số lẻ)
    
    for (int i = 0; i < n; i++) {
        if (a[i] % 2 == 0) {
            b[m++] = a[i];
        } else {
            c[p++] = a[i];
        }
    }
}

int main() {
    int n;
    int a[MAX], b[MAX], c[MAX];
    int m, p;
    
    cout << "Nhập số lượng phần tử của mảng: ";
    cin >> n;
    while (n <= 0 || n > MAX) {
        cout << "Số lượng phần tử không hợp lệ! Nhập lại: ";
        cin >> n;
    }
    
    cout << "Nhập các phần tử của mảng: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    
    // Tách mảng thành số chẵn và số lẻ
    TachMang(a, n, b, m, c, p);
    
    // Xuất mảng số chẵn
    cout << "Mảng chứa các số chẵn: ";
    for (int i = 0; i < m; i++) {
        cout << b[i] << " ";
    }
    cout << endl;
    
    // Xuất mảng số lẻ
    cout << "Mảng chứa các số lẻ: ";
    for (int i = 0; i < p; i++) {
        cout << c[i] << " ";
    }
    cout << endl;
    
    return 0;
}
