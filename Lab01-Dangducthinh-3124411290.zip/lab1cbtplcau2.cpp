#include <iostream>
#include <cstring>
using namespace std;

#define MAX 20

// Khai báo cấu trúc LoaiHoa
struct LoaiHoa {
    char Ten[50];
    int SoLuong;
    char DVT[10];
    double DonGia;
};

// Khai báo cấu trúc DanhSachLoaiHoa
struct DanhSachLoaiHoa {
    LoaiHoa aHoa[MAX];
    int SoLuong;
};

// Hàm nhập danh sách loại hoa
void NhapDanhSach(DanhSachLoaiHoa &ds) {
    cout << "Nhap so luong loai hoa: ";
    cin >> ds.SoLuong;
    cin.ignore();
    for (int i = 0; i < ds.SoLuong; i++) {
        cout << "Nhap loai hoa thu " << i + 1 << ":\n";
        cout << "Ten loai: "; cin.getline(ds.aHoa[i].Ten, 50);
        cout << "So luong: "; cin >> ds.aHoa[i].SoLuong;
        cin.ignore();
        cout << "Don vi tinh: "; cin.getline(ds.aHoa[i].DVT, 10);
        cout << "Don gia: "; cin >> ds.aHoa[i].DonGia;
        cin.ignore();
    }
}

// Hàm xuất danh sách loại hoa
void XuatDanhSach(DanhSachLoaiHoa ds) {
    cout << "\nDanh sach loai hoa:\n";
    for (int i = 0; i < ds.SoLuong; i++) {
        cout << "Ten loai: " << ds.aHoa[i].Ten << endl;
        cout << "So luong: " << ds.aHoa[i].SoLuong << endl;
        cout << "Don vi tinh: " << ds.aHoa[i].DVT << endl;
        cout << "Don gia: " << ds.aHoa[i].DonGia << endl;
        cout << "------------------------\n";
    }
}

// Hàm tìm loại hoa theo tên loại
int TimLoaiHoa(DanhSachLoaiHoa ds, char *tenloai) {
    for (int i = 0; i < ds.SoLuong; i++) {
        if (strcmp(ds.aHoa[i].Ten, tenloai) == 0) {
            return i;
        }
    }
    return -1;
}

// Hàm xử lý bán hoa
void XuLyBanHoa(DanhSachLoaiHoa &ds, char *tenloai, int soluong) {
    int index = TimLoaiHoa(ds, tenloai);
    if (index == -1) {
        cout << "Khong tim thay loai hoa " << tenloai << " trong danh sach.\n";
        return;
    }
    if (ds.aHoa[index].SoLuong < soluong) {
        cout << "Khong du so luong de ban.\n";
    } else {
        double tongTien = soluong * ds.aHoa[index].DonGia;
        ds.aHoa[index].SoLuong -= soluong;
        cout << "Ban thanh cong! Tong tien: " << tongTien << " VND\n";
    }
}

// Hàm main
int main() {
    DanhSachLoaiHoa ds;
    NhapDanhSach(ds);
    XuatDanhSach(ds);
    
    char tenloai[50];
    int soluong;
    cout << "\nNhap ten loai hoa can mua: "; cin.getline(tenloai, 50);
    cout << "Nhap so luong can mua: "; cin >> soluong;
    
    XuLyBanHoa(ds, tenloai, soluong);
    
    cout << "\nDanh sach sau khi ban:\n";
    XuatDanhSach(ds);
    
    return 0;
}
